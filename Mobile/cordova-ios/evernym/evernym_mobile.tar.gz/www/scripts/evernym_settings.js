var EVERNYM_ICONS = {
    sports: {
        image: 'sports-icons-01.jpg',
        width: 70,
        height: 70,
        imagewidth: 700,
        imageheight: 700,
        columns: 10,
        rows: 10,
        count: 100
    },
    animals: {
        image: 'animal-icons.png',
        width: 135,
        height: 135,
        imagewidth: 945,
        imageheight: 945,
        columns: 7,
        rows: 7,
        count: 46
    },
    

}