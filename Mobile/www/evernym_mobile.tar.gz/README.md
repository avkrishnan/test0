Knockout-jQueryMobile
=====================

A simple example of integration between jQueryMobile with KnockoutJS, as described in this blog post:

http://www.scottlogic.co.uk/blog/colin/2012/10/integrating-knockout-and-jquerymobile/