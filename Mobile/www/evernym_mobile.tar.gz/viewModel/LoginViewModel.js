﻿/*globals ko*/

function LoginViewModel() {
    /// <summary>
    /// A view model that represents a single tweet
    /// </summary>
    
    // --- properties
    
    this.template = "loginView";
    
    this.accountName = ko.observable();
    
    this.password = ko.observable();
    
    var  dataService = new EvernymLoginService();
    
    this.loginCommand = function() {
        var callbacks = {
        success: loginSuccess,
        error: loginError
        };
        
        var loginModel = {};
        
        loginModel.accountName = this.accountName();
        loginModel.password = this.password();
        loginModel.appToken = 'sNQO8tXmVkfQpyd3WoNA6_3y2Og=';
        
        dataService.accountLogin(loginModel, callbacks);
    }
    
    this.showRegistration = function(){
        
        $.mobile.changePage("#" + signupViewModel.template);
        
    }
    
    this.logoutCommand = function() {
        var cookie = localStorage.getItem("accessToken");
        if (cookie) {
            var callbacks = {
            success: logoutSuccess,
            error: logoutError
            };
            dataService.accountLogout(cookie, callbacks);
            //logger.log('You successfully logged out!', null, 'login', true);
        }
    }
    
    function loginSuccess(args) {
                
        
        localStorage.removeItem('accessToken');
        if (args.accessToken) {
            
            localStorage.setItem("accessToken", args.accessToken);
            $.mobile.changePage("#" + channelListViewModel.template);
            channelListViewModel.activate();
        } else {
            loginError();
            return;
        }
        
        //logger.log('You successfully logged in!', null, 'login', true);
    }
    
    function loginError() {
        alert("LOGIN FAILED");
        localStorage.removeItem('accessToken');
        //logger.logError('Your login failed, please try again!', null, 'login', true);
    }
    
    function logoutSuccess() {
        
        localStorage.removeItem('accessToken');
        //logger.logError('You successfully logged out!', null, 'login', true);
    }
    
    function logoutError() {
        
        //logger.logError('Your log out failed, please try again!', null, 'login', true);
    }
    
    
    // --- private functions
    function parseDate(date) {
        /// <summary>
        /// Parses the tweet date to give a more readable format.
        /// </summary>
        var diff = (new Date() - new Date(date)) / 1000;
        
        if (diff < 60) {
            return diff.toFixed(0) + " seconds ago";
        }
        
        diff = diff / 60;
        if (diff < 60) {
            return diff.toFixed(0) + " minutes ago";
        }
        
        diff = diff / 60;
        if (diff < 10) {
            return diff.toFixed(0) + " hours ago";
        }
        
        diff = diff / 24;
        
        if (diff.toFixed(0) === 1) {
            return diff.toFixed(0) + " day ago";
        }
        
        return diff.toFixed(0) + " days ago";
    }
    

    
    
}
